// supabaseClient.js
import { createClient } from '@supabase/supabase-js';

// Substitua com a URL e a chave de API do seu projeto no Supabase
const supabaseUrl = 'https://your-project-id.supabase.co'; 
const supabaseKey = 'your-anon-key'; 
export const supabase = createClient(supabaseUrl, supabaseKey);

// App.js
import React, { useState } from 'react';
import { View, Button } from 'react-native';
import Login from './Login';
import SignUp from './SignUp';

export default function App() {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 20 }}>
      <Button
        title={isLogin ? 'Criar uma conta' : 'Já tenho uma conta'}
        onPress={() => setIsLogin(!isLogin)}
      />
      {isLogin ? <Login /> : <SignUp />}
    </View>
  );
}
